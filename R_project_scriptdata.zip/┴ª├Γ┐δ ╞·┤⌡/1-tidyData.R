library("dplyr")

#####1.case data tidy
#read case Data 
dailyCaseData <-read.csv("Case/owid-covid-data.csv", header = TRUE) 
dailyCaseData[is.na(dailyCaseData)] <- 0

#remove coloumns that are not case data (such as continent)
dailyCaseData <- dailyCaseData[-c(2,3,17,26,27,28,29,30,31,32,33,34,35,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59)]

#get month/Year from date
dailyCaseData$date <- as.Date(dailyCaseData$date)
dailyCaseData$YearMonth <- as.integer(format(dailyCaseData$date,format="%Y%m"))

#monthly average case data
monthlyCaseData <- 
  dailyCaseData %>% group_by(iso_code, YearMonth) %>%
  summarise(across( -c("date") , mean))

#remove 2021 05 (we only have 8 days in 2021 05. average meaningless)
monthlyCaseData <- monthlyCaseData[!(monthlyCaseData$YearMonth==202105),]

#####2.policy data tidy and inner join to case data
#read policy Data
policy_list <- list(testing_policy <- read.csv("Policy/covid-19-testing-policy.csv", header = TRUE)
                    ,contact_tracing <- read.csv("Policy/covid-contact-tracing.csv", header = TRUE)
                    ,containment_and_health <- read.csv("Policy/covid-containment-and-health-index.csv", header = TRUE)
                    ,vaccination_policy<- read.csv("Policy/covid-vaccination-policy.csv", header = TRUE)
                    ,debt_relief<- read.csv("Policy/debt-relief-covid.csv", header = TRUE)
                    ,public_transport <- read.csv("Policy/public-transport-covid.csv", header = TRUE)
                    ,school_closures <- read.csv("Policy/school-closures-covid.csv", header = TRUE)
                    ,stay_at_home <- read.csv("Policy/stay-at-home-covid.csv", header = TRUE)
                    ,visitors_transit <- read.csv("Policy/visitors-transit-covid.csv", header = TRUE)
                    ,workplace_closures <- read.csv("Policy/workplace-closures-covid.csv", header = TRUE)
                    ,workplace_visitors <- read.csv("Policy/workplace-visitors-covid.csv", header = TRUE)
                    ,face_covering <- read.csv("Policy/face-covering-policies-covid.csv", header = TRUE)
                    ,income_support <- read.csv("Policy/income-support-covid.csv", header = TRUE)
                    ,internal_movement <- read.csv("Policy/internal-movement-covid.csv", header = TRUE)
                    ,public_campaign<- read.csv("Policy/public-campaigns-covid.csv", header = TRUE)
                    ,public_event<- read.csv("Policy/public-events-covid.csv", header = TRUE)
                    ,public_gathering<-read.csv("Policy/public-gathering-rules-covid.csv", header = TRUE))
#monthly average policy data
for (i in 1:length(policy_list)){
  policy_list[[i]]$Day <- as.Date(policy_list[[i]]$Day)
  policy_list[[i]]$YearMonth <- as.integer(format(policy_list[[i]]$Day,format="%Y%m"))
  policy_list[[i]] <- 
    policy_list[[i]]%>%
    group_by(Code, YearMonth) %>%
    summarise(across( -c("Day", "Entity") , mean))
}

#inner join with case data
for (i in policy_list)
  monthlyCaseData <- inner_join(monthlyCaseData, i, by=c("iso_code" = "Code", "YearMonth"))

#####3.economy data tidy and inner join to previous data
#read CCI and tidy
CCI <- read.csv("Economy/CCI.csv",  header = TRUE)
CCI$TIME <- as.Date(CCI$TIME)
CCI$YearMonth <- as.integer(format(CCI$TIME,format="%Y%m"))
CCI <-
  CCI %>%
  group_by(LOCATION, YearMonth) %>%
  summarise(Value)
names(CCI)[3] <- "CCI"

#inner join with previous data
CCIMonthlyData <- inner_join(monthlyCaseData, CCI, by=c("iso_code" = "LOCATION", "YearMonth"))

#Add CCI change : monthly change in CCI value
CCIMonthlyData <- CCIMonthlyData %>% mutate(CCIChange = ifelse(iso_code == lag(iso_code), CCI - lag(CCI), 0))
CCIMonthlyData[is.na(CCIMonthlyData)] <- 0

#read CLI and tidy
CLI <- read.csv("Economy/CLI.csv",  header = TRUE)
CLI$TIME <- as.Date(CLI$TIME)
CLI$YearMonth <- as.integer(format(CLI$TIME,format="%Y%m"))
CLI <-
  CLI %>%
  group_by(LOCATION, YearMonth) %>%
  summarise(across( c("Value") , mean))
names(CLI)[3] <- "CLI"

#inner join with previous data
CLIMonthlyData <- inner_join(monthlyCaseData, CLI, by=c("iso_code" = "LOCATION", "YearMonth"))

#Add CLI change : monthly change in CCI value
CLIMonthlyData <- CLIMonthlyData %>% mutate(CLIChange = ifelse(iso_code == lag(iso_code), CLI - lag(CLI), 0))
CLIMonthlyData[is.na(CLIMonthlyData)] <- 0

#write final data
write.csv(CCIMonthlyData , "CCIMonthlyData.csv", row.names = FALSE)
write.csv(CLIMonthlyData , "CLIMonthlyData.csv", row.names = FALSE)


