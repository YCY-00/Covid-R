library("dplyr")

#read Data
Data <-read.csv("CCIMonthlyData.csv", header = TRUE) 

#change month data format 
#currently 202101 - 202012 = 89. change this to 1
Data <- Data %>% 
  mutate(YearMonth = YearMonth%/%100 * 12 + YearMonth %% 100 - 1)
Data[is.na(Data)] <- 0

#remove some useless columns
Data <- Data[,-c(5,8,11,14,26,30)] #we're using average. so delete smoothed data
Data <- Data[,-c(11:18)] #only few countries have icu/hosp data. can't use this.
Data <- Data[,-c(17,20)] #remove composite policies that are only sum of other policies

#case & death part
coeffs <- c(5.073e-06, 5.220e-06) #coefficient of new_cases and total_deaths
caseData <- Data %>% filter(total_cases!=0) %>% group_by(YearMonth) %>% 
  summarise(month_passed = YearMonth - 24241,
            new_case_rate_mean = mean(new_cases/total_cases), 
            death_rate_mean = mean(total_deaths/total_cases)) %>% 
  mutate(sum_rate = new_case_rate_mean * coeffs[2] + death_rate_mean * coeffs[1])
par(mfrow=c(1,2))
plot(caseData$month_passed, caseData$new_case_rate_mean, xlab = "passed month", ylab = "mean new case rate")
plot(caseData$month_passed, caseData$death_rate_mean, xlab = "passed month", ylab = "mean death rate")
par(mfrow=c(1,1))
plot(caseData$month_passed, caseData$sum_rate, xlab = "passed month", ylab = "sum rate")

#vaccination part
vacData <-  Data %>% filter(total_vaccinations_per_hundred!=0) %>% group_by(YearMonth) %>% 
  summarise(month_passed = YearMonth - 24241,
            full_vaccination_rate_mean = mean(people_fully_vaccinated_per_hundred / total_vaccinations_per_hundred))
plot(vacData$month_passed, vacData$full_vaccination_rate_mean, xlab = "passed month", ylab = "mean full vaccination rate")