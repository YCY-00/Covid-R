library("dplyr")

#read Data - CCI
Data <-read.csv("CCIMonthlyData.csv", header = TRUE) 

#change month data format 
#currently 202101 - 202012 = 89. change this to 1
Data <- Data %>% 
  mutate(YearMonth = YearMonth%/%100 * 12 + YearMonth %% 100 - 1)
Data[is.na(Data)] <- 0

#remove some useless columns
Data <- Data[,-c(5,8,11,14,26,30)] #we're using average. so delete smoothed data
Data <- Data[,-c(11:18)] #only few countries have icu/hosp data. can't use this.
Data <- Data[,-c(17,20)] #remove composite policies that are only sum of other policies

#CCI change : linear regression with backward elimination
selectNames <- names(Data)[c(2:32)] 
formula = as.formula(paste('CCIChange~',paste(selectNames,collapse = '+')))
full.model <- lm(formula, data = Data)
step.model <- step(direction = "backward", object = full.model)
summary(step.model)

#read Data - CLI
Data <-read.csv("CLIMonthlyData.csv", header = TRUE) 

#change month data format 
#currently 202101 - 202012 = 89. change this to 1
Data <- Data %>% 
  mutate(YearMonth = YearMonth%/%100 * 12 + YearMonth %% 100 - 1)
Data[is.na(Data)] <- 0

#remove some useless columns
Data <- Data[,-c(5,8,11,14,26,30)] #we're using average. so delete smoothed data
Data <- Data[,-c(11:18)] #only few countries have icu/hosp data. can't use this.
Data <- Data[,-c(17,20)] #remove composite policies that are only sum of other policies

#CLI change : linear regression with backward elimination
selectNames<-names(Data)[c(2:32)]
formula <- as.formula(paste('CLIChange ~ ', paste(selectNames, collapse = '+')))
full.model <- lm(formula, data = Data)
step.model <- step(direction = "backward", object = full.model)
summary(step.model)