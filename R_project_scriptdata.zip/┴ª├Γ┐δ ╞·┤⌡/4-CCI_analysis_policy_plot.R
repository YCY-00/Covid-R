library("dplyr")
Data<-read.csv("CCIMonthlyData.csv", header = TRUE)

passmonth<-Data$YearMonth-202001
for (i in 1:555){
if(passmonth[i]>=100){
passmonth[i]<-passmonth[i]-100+12}
}

#stringency index : total stringency compare
plot(Data$stringency_index, Data$CCIChange)
abline(lm(Data$CCIChange ~ Data$stringency_index), lty = 2, col = "red")


par(mfrow = c(1, 1))
plot(Data$stringency_index, Data$CCI)
abline(lm(Data$CCI ~ Data$stringency_index), lty = 2, col = "red")

par(mfrow = c(2,2))
#School and Workplace Closures
plot(Data$school_closures, Data$CCIChange)
abline(lm(Data$CCIChange ~ Data$school_closures), lty = 2, col = "red")

plot(Data$workplace_closures, Data$CCIChange)
abline(lm(Data$CCIChange ~ Data$workplace_closures), lty = 2, col = "red")

plot(Data$school_closures[1:15], Data$CCIChange[1:15])
abline(lm(Data$CCIChange[1:15] ~ Data$school_closures[1:15]), lty = 2, col = "red")

plot(Data$workplace_closures[1:15], Data$CCIChange[1:15])
abline(lm(Data$CCIChange[1:15] ~ Data$workplace_closures[1:15]), lty = 2, col = "red")

par(mfrow = c(2,2))
plot(Data$school_closures, Data$CCI)
abline(lm(Data$CCI ~ Data$school_closures), lty = 2, col = "red")

plot(Data$workplace_closures, Data$CCI)
abline(lm(Data$CCI ~ Data$workplace_closures), lty = 2, col = "red")


#Cancellation of Public Events and Gatherings
par(mfrow = c(2,2))
plot(Data$cancel_public_events, Data$CCIChange)
abline(lm(Data$CCIChange ~ Data$cancel_public_events), lty = 2, col = "red")

plot(Data$restriction_gatherings, Data$CCIChange)
abline(lm(Data$CCIChange ~ Data$restriction_gatherings), lty = 2, col = "red")

par(mfrow = c(2,2))
plot(Data$cancel_public_events, Data$CCI)
abline(lm(Data$CCI ~ Data$cancel_public_events), lty = 2, col = "red")

plot(Data$restriction_gatherings, Data$CCI)
abline(lm(Data$CCI ~ Data$restriction_gatherings), lty = 2, col = "red")


#Stay at home
par(mfrow = c(1, 1))
plot(Data$stay_home_requirements, Data$CCIChange)
abline(lm(Data$CCIChange ~ Data$stay_home_requirements), lty = 2, col = "red")

par(mfrow = c(1, 1))
plot(Data$stay_home_requirements, Data$CCI)
abline(lm(Data$CCI ~ Data$stay_home_requirements), lty = 2, col = "red")


#face covering
par(mfrow = c(1, 1))
plot(Data$facial_coverings, Data$CCI)
abline(lm(Data$CCI ~ Data$facial_coverings), lty = 2, col = "red")

par(mfrow = c(1, 1))
plot(Data$facial_coverings, Data$CCIChange)
abline(lm(Data$CCIChange ~ Data$facial_coverings), lty = 2, col = "red")



#public campaign
par(mfrow = c(1, 1))
plot(Data$public_information_campaigns, Data$CCI)
abline(lm(Data$CCI ~ Data$public_information_campaigns), lty = 2, col = "red")

par(mfrow = c(1, 1))
plot(Data$public_information_campaigns, Data$CCIChange)
abline(lm(Data$CCIChange ~ Data$public_information_campaigns), lty = 2, col = "red")

#Public transport and Domestic Travel
par(mfrow = c(2, 2))
plot(Data$close_public_transport, Data$CCI)
abline(lm(Data$CCI ~ Data$close_public_transport), lty = 2, col = "red")

plot(Data$restrictions_internal_movements, Data$CCI)
abline(lm(Data$CCI ~ Data$restrictions_internal_movements), lty = 2, col = "red")

par(mfrow = c(2, 2))
plot(Data$close_public_transport, Data$CCIChange)
abline(lm(Data$CCIChange ~ Data$close_public_transport), lty = 2, col = "red")

plot(Data$restrictions_internal_movements, Data$CCIChange)
abline(lm(Data$CCIChange ~ Data$restrictions_internal_movements), lty = 2, col = "red")

#Testing and contact tracing
par(mfrow = c(2, 2))
plot(Data$testing_policy, Data$CCI)
abline(lm(Data$CCI ~ Data$testing_policy), lty = 2, col = "red")

plot(Data$contact_tracing, Data$CCI)
abline(lm(Data$CCI ~ Data$contact_tracing), lty = 2, col = "red")

par(mfrow = c(2, 2))
plot(Data$testing_policy, Data$CCIChange)
abline(lm(Data$CCIChange ~ Data$testing_policy), lty = 2, col = "red")

plot(Data$contact_tracing, Data$CCIChange)
abline(lm(Data$CCIChange ~ Data$contact_tracing), lty = 2, col = "red")

#vaccination policy
par(mfrow = c(1, 1))
plot(Data$vaccination_policy, Data$CCI)
abline(lm(Data$CCI ~ Data$vaccination_policy), lty = 2, col = "red")

par(mfrow = c(1, 1))
plot(Data$vaccination_policy, Data$CCIChange)
abline(lm(Data$CCIChange ~ Data$vaccination_policy), lty = 2, col = "red")

#income support and debt relief

par(mfrow = c(2, 2))
plot(Data$income_support, Data$CCI)
abline(lm(Data$CCI ~ Data$income_support), lty = 2, col = "red")

plot(Data$debt_relief, Data$CCI)
abline(lm(Data$CCI ~ Data$debt_relief), lty = 2, col = "red")

par(mfrow = c(2, 2))
plot(Data$income_support, Data$CCIChange)
abline(lm(Data$CCIChange ~ Data$income_support), lty = 2, col = "red")

plot(Data$debt_relief, Data$CCIChange)
abline(lm(Data$CCIChange ~ Data$debt_relief), lty = 2, col = "red")
